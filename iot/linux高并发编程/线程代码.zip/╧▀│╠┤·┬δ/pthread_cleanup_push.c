#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <pthread.h>

#define dbgOut(args...) \
do{ \
	char b__[1024]; \
	sprintf(b__,args); \
	fprintf(stdout,"[%s, %s, %d] %s", __FILE__, __FUNCTION__,__LINE__,b__); \
}while(0)

//线程清理函数
void cleanup(void *arg)
{
    dbgOut("thread clean up\n");

    int *tmp;
    tmp = (int *)arg;

    free(tmp);
}

//线程函数
void *func(void *arg)
{
	dbgOut("thread starting ...\n");

	int *p;
	p = (int *)malloc(10); //在堆上申请了10个字节的空间
	*p = 10;

	//注册线程清理函数
	pthread_cleanup_push(cleanup, (void *)p);
//    pthread_cleanup_pop(0); //如果在此处调用你pthread_cleanup_pop(0)会产生什么样的结果？
    int i;
    for (i = 0; i < 10; i++)
    {
        dbgOut("%d\n", (*p)++);
        sleep(1);
    }

    free(p); //释放堆空间
    pthread_cleanup_pop(0); //如果在此处调用pthread_cleanup_pop(0)的目的是什么？ 将线程清理函数删除
	pthread_exit(NULL);
   // pthread_cleanup_pop(0);
}

int main(int argc, char *argv[])
{
	int ret;
	pthread_t t1;

	ret = pthread_create(&t1, NULL, func, NULL);
	if (ret != 0)
	{
		printf("pthread_create error\n");
		return 0;
	}

    sleep(5);
	pthread_cancel(t1);

    pthread_join(t1, NULL);

    return 0;
}