#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#define dbgOut(args...) \
do{ \
	char b__[1024]; \
	sprintf(b__,args); \
	fprintf(stdout,"[%s, %s, %d] %s", __FILE__, __FUNCTION__,__LINE__,b__); \
}while(0)

//线程函数
void *func(void *arg)
{
    //设置线程不能够被取消
    pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);

	int i = 0;
	while (1)
	{
		dbgOut("%d\n", i);
		i++;
		if (i >= 4)
		    //将线程设置为可取消状态
		    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

		sleep(1);
	}
}

int main(int argc, char *argv[])
{
	int ret;
	pthread_t t1;

	ret = pthread_create(&t1, NULL, func, NULL);
	if (ret != 0)
	{
		dbgOut("pthread_create error\n");
		return 0;
	}

	sleep(1);
	pthread_cancel(t1); //向t1线程发送取消信号
	sleep(5);
	pthread_cancel(t1); //向t1线程发送取消信号

	while (1);
}
