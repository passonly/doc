#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

//线程函数
void *func(void *arg)
{
    int i;
	printf("hello\n");
	for (i = 0; i < 1000000000; i++)
	{
	    printf("thread i: %d\n", i);
	}

	//如果该线程函数返回，则代表该线程结束
	while (1);
}

void main()
{
	int ret;
	pthread_t t1; //保存线程ID的变量

	//创建一个线程
	ret = pthread_create(&t1, NULL, func, NULL);
	#if 0
	printf("t1 %ld\n", t1);
	if (ret != 0)
	{
		printf("pthread_create error\n");
		return ;
	}

	int i;
	for (i = 0; i < 1000000000; i++)
	{
	    printf("main i: %d\n", i);
	}
	while (1);
    #endif

}
