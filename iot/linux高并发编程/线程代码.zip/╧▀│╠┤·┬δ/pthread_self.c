#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

//线程函数
void *func(void *arg)
{
	printf("hello： %ld\n", pthread_self());//获取线程的ID
	//如果该线程函数返回，则代表该线程结束
	while (1);
}

void main()
{
	int ret;
	pthread_t t1;
	//t1的值并不是LWP的值 只是pthread库用来标识该线程的一个编号
	ret = pthread_create(&t1, NULL, func, NULL);
	printf("t1: %ld\n", t1);
	if (ret != 0)
	{
		printf("pthread_create error\n");
		return ;
	}

	while (1);
}
