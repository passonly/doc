#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

#include <signal.h>
#include <pthread.h>

#define _GNU_SOURCE
#include <sched.h>

#define FIBER_STACK 8192
int global_a;
void * stack;

int do_something(){
    printf("This is son, the tid is:%d, the a is: %d\n", pthread_self(), ++global_a);

    exit(1);
}

int main(){

    global_a = 1;
    stack = malloc(FIBER_STACK);//为子线程申请系统堆栈

    if(!stack)
    {
        printf("The stack failed\n");
        return 0;
    }
    printf("creating son thread!!!\n");

    clone(&do_something, (char *)stack, CLONE_THREAD, NULL);//创建子线程

    while (1);

    return 0;
}
