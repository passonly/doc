#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <pthread.h>

#define dbgOut(args...) \
do{ \
	char b__[1024]; \
	sprintf(b__,args); \
	fprintf(stdout,"[%s, %s, %d] %s", __FILE__, __FUNCTION__,__LINE__,b__); \
}while(0)

//线程清理函数
void cleanup(void *arg)
{
    dbgOut("thread clean up\n");

    int *tmp;
    tmp = (int *)arg;

    free(tmp);
}

//线程函数
void *func(void *arg)
{
    //pthread_detach(pthread_self()); //在线程内部将线程自己分离
	dbgOut("thread starting ...\n");

	int *p;
	p = (int *)malloc(10);
	*p = 10;

	//注册线程清理函数
	pthread_cleanup_push(cleanup, (void *)p);

    int i;
    for (i = 0; i < 10; i++)
    {
        dbgOut("%d\n", (*p)++);
        sleep(1);
    }

    pthread_cleanup_pop(0);
	pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
	int ret;
	pthread_t t1;

	ret = pthread_create(&t1, NULL, func, NULL);
	if (ret != 0)
	{
		printf("pthread_create error\n");
		return 0;
	}

	pthread_detach(t1); //将t1线程分离，t1线程退出后系统会自动回收t1线程的资源

	while (1);
    return 0;
}