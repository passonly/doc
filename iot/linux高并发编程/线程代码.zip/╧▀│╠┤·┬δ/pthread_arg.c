#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#define dbgOut(args...) \
do{ \
	char b__[1024]; \
	sprintf(b__,args); \
	fprintf(stdout,"[%s, %s, %d] %s", __FILE__, __FUNCTION__,__LINE__,b__); \
}while(0)

typedef struct student
{
	char name[32];
	int age;
}stu;

//线程函数
void *func2(void *arg)
{
	stu tmp;
	tmp = *((stu *)arg);
	dbgOut("name: %s, age: %d\n", tmp.name, tmp.age);

}

//线程函数
void *func(void *arg)
{
	dbgOut("hello： %ld, %p\n", pthread_self(), ((int *)arg));
	dbgOut("hello： %ld, %d\n", pthread_self(), *((int *)arg));

	//如果该线程函数返回，则代表该线程结束
	//return NULL;
	while (1);
}

void main()
{
	int ret;

	int i;
	pthread_t a[3];

	int *p;
	for (i = 0; i < 3; i++)
	{
	    p = (int *)malloc(10); //在堆上申请了10个字节的空间，模拟主线程将需要处理的数据存储到了进程的地址空间的堆上
	    *p = i;
		//向线程函数传递整型数据
		//pthread_create(&a[i], NULL, func, (void *)&i);
		pthread_create(&a[i], NULL, func, (void *)p);
	}

	stu s;
	memset(s.name, 0, sizeof(s.name));
	strcpy(s.name, "zhangsan");
	s.age = 18;

	pthread_t t;
	//向线程函数传递结构体数据
	pthread_create(&t, NULL, func2, (void *)&s);

	s.age = 19;

	while (1);
}
