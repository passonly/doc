#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#define OK  0
#define FHE 1
#define FTE 2

typedef struct student
{
	char name[32];
	int age;
}stu;

#define dbgOut(args...) \
do{ \
	char b__[1024]; \
	sprintf(b__,args); \
	fprintf(stdout,"[%s, %s, %d] %s", __FILE__, __FUNCTION__,__LINE__,b__); \
}while(0)

void *thread(void *arg)
{
	int i = 0;
	while(1)
	{
		dbgOut("I am runing\n");
		sleep(1);
		i++;
		if(i==10)
		{
			//pthread_exit((void *)1); //线程会在此处结束
			//思考：为什么需要用(void*)1， 而不是直接传1呢？
			//思考：能否传递自定义类型呢？
			/*
                stu s;
                s.age  =  18;
                pthread_exit((void *)&s); //从语法上这是没有问题，但是其他线程能否正确获得结构体中的内容不得而知，到底能还是不能呢？后面再告诉大家
			*/
			//思考：能否传递字符串呢？
		//	pthread_exit((void *)"hello");
			pthread_exit((void *)FHE);
		}
	}
	return NULL;
}

int main(int argc, char *argv[])
{
	int ret = 0;
	pthread_t tid;

	ret = pthread_create(&tid, NULL, thread, NULL);
	if(ret != 0)
		perror("pthread_create");

    while (1);
	return 0;
}
