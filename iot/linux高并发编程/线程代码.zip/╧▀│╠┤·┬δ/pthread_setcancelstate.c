#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#define dbgOut(args...) \
do{ \
	char b__[1024]; \
	sprintf(b__,args); \
	fprintf(stdout,"[%s, %s, %d] %s", __FILE__, __FUNCTION__,__LINE__,b__); \
}while(0)

//线程函数
void *func(void *arg)
{
	int i = 0;

	//设置该线程不能被取消
	pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
	for (i = 0; i < 5; i++)
	{
		dbgOut("%d\n", i);
		sleep(1);
	}
	//设置该线程能被取消
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
}

int main(int argc, char *argv[])
{
	int ret;
	pthread_t t1;

	ret = pthread_create(&t1, NULL, func, NULL);
	if (ret != 0)
	{
		dbgOut("pthread_create error\n");
		return 0;
	}

	pthread_cancel(t1);

	while (1);
}
