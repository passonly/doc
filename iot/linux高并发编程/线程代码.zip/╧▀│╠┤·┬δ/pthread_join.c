#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <pthread.h>

#define dbgOut(args...) \
do{ \
	char b__[1024]; \
	sprintf(b__,args); \
	fprintf(stdout,"[%s, %s, %d] %s", __FILE__, __FUNCTION__,__LINE__,b__); \
}while(0)

struct stu{
    char name[32];
    int age;
};

//线程函数
void *func(void *arg)
{
	dbgOut("thread starting ...\n");

	/*
    struct stu s;
    strcpy(s.name, "zhangsan");
    s.age = 18;

    int x = 100;
    */

	int *p;
	p = (int *)malloc(10);
	*p = 10;
    dbgOut("%p\n",p);

	//pthread_exit((void *)10);
	//pthread_exit((void *)"FrameHeadError");
	//pthread_exit((void *)&s);
	pthread_exit((void *)p);
}

//线程函数
void *func2(void *arg)
{
	dbgOut("thread starting ...\n");

    struct stu s;
    strcpy(s.name, "zhangsan");
    s.age = 18;

    int x = 200;

    dbgOut("%p\n", &x);
	pthread_exit((void *)&x);
}

int main(int argc, char *argv[])
{
	int ret;
	pthread_t t1;

	ret = pthread_create(&t1, NULL, func, NULL);
	if (ret != 0)
	{
		printf("pthread_create error\n");
		return 0;
	}

    int *val;
   // char *val;
    //主线程
    //struct stu *val;
    pthread_join(t1, (void **)&val);

    //创建另外一个线程，让新的线程分配到原来退出线程的栈空间
    pthread_t t2;
	ret = pthread_create(&t2, NULL, func2, NULL);
	if (ret != 0)
	{
		printf("pthread_create error\n");
		return 0;
	}

	pthread_join(t2, NULL); //sleep(1);

    dbgOut("%p\n", val);
    dbgOut("%d\n", *val);
    free(val);

  //  dbgOut("name:%s, age: %d\n", (*val).name, (*val).age);
  //  dbgOut("name:%s, age: %d\n", val->name, val->age);
 //   dbgOut("%s\n", val);

//   dbgOut("%d\n", *val);

    return 0;
}