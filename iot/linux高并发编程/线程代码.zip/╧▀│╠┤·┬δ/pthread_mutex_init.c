#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <pthread.h>

#define dbgOut(args...) \
do{ \
	char b__[1024]; \
	sprintf(b__,args); \
	fprintf(stdout,"[%s, %s, %d] %s", __FILE__, __FUNCTION__,__LINE__,b__); \
}while(0)

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t mutex1;

int cnt = 0;

//线程函数
void *func(void *arg)
{
	int i;
	for (i = 0; i < 50000000; i++)
	{
	    dbgOut("%ld, %d\n", pthread_self(), i);
		//加锁 P操作
		//pthread_mutex_lock(&mutex);
		pthread_mutex_lock(&mutex1);
		cnt++;

		dbgOut("%ld, %d\n", pthread_self(), cnt);
		//解锁 V操作
		//pthread_mutex_unlock(&mutex);
		pthread_mutex_unlock(&mutex);
	}
	dbgOut("%ld, %d\n", pthread_self(), cnt);
}

int main(int argc, char *argv[])
{
	int ret;
	pthread_t t[2];
	int i;

	//使用pthread_mutex_init函数初始化互斥锁
	pthread_mutex_init(&mutex1, NULL);

	for (i = 0; i < 2; i++)
	{
		ret = pthread_create(&t[i], NULL, func, NULL);
		if (ret != 0)
		{
			printf("pthread_create error\n");
			return 0;
		}
	}

	for (i = 0; i < 2; i++)
	    pthread_join(t[i], NULL);

	//使用pthread_mutex_destroy函数销毁互斥锁
	pthread_mutex_destroy(&mutex1);

	while (1);

	return 0;
}