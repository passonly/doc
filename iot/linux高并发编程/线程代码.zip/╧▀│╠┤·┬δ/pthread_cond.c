#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>

pthread_cond_t cond;
pthread_mutex_t mutex;
/*
线程工作函数--消费者
*/
void *thread_work_func(void *dev)
{
        printf("线程等待运行:   %ld\n",pthread_self());

    while (1)
    {
        //互斥锁上锁
        pthread_mutex_lock(&mutex);
        printf("互斥锁上锁成功: %ld \n",pthread_self());
        pthread_cond_wait(&cond,&mutex); //内部先解锁再加锁

        printf("线程开始运行:   %ld\n",pthread_self());

        pthread_mutex_unlock(&mutex);
    }
}

//信号工作函数---生产者
void signal_work_func(int sig)
{
    printf("正在唤醒休眠的线程.\n");
    pthread_mutex_lock(&mutex);
    pthread_cond_broadcast(&cond); //广播唤醒
    //pthread_cond_signal (&cond); //唤醒单个休眠的线程
    pthread_mutex_unlock(&mutex);
}

int main(int argc,char **argv)
{
    //注册要捕获的信号
    signal(SIGINT,signal_work_func);

    //初始化条件变量
    pthread_cond_init(&cond,NULL);
    //初始化互斥锁
    pthread_mutex_init(&mutex,NULL);

    /*创建子线程*/
    pthread_t thread_id;
    int i;
    for(i=0;i<10;i++)
    {
        pthread_create(&thread_id,NULL,thread_work_func,NULL);

        //设置线程的分离属性
        pthread_detach(thread_id);
        sleep(1);
    }

    while (1)
    {
        sleep(1);
    }

    //销毁条件变量
    pthread_cond_destroy(&cond);
    //销毁互斥锁
    pthread_mutex_destroy(&mutex);

    return 0;
}