#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    pid_t pid;

    pid = fork();

    if (0 == pid) //子进程返回
    {
        while (1)
        {
            printf("child process\n");
            sleep(1);
        }
    }
    else if (pid > 0) //父进程返回
    {
        while (1)
        {
            printf("parent process\n");
            sleep(1);
        }
    }
    return 0;
}