//写端代码：
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define FIFO "/tmp/1.fifo"

void main()
{
	int ret;
	//unlink(FIFO);
	if (access(FIFO, F_OK))
	{
		//创建一个管道文件
		ret = mkfifo(FIFO, 0644);
		if (-1 == ret)
		{
			printf("error\n");
			return ;
		}
	}
	//打开管道文件
	int fd;
	fd = open(FIFO, O_RDWR);

	write(fd, "hello", 6);

//	while (1);
}
