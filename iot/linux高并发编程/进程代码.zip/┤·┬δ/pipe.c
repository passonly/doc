#include <sys/types.h>
#include <sys/stat.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>


void func(int signo)
{
    printf("broken pipe ...\n");
}

int main()
{
	int fd[2]; //保存管道的两个文件描述符
	int ret;
	ret = pipe(fd); //创建一个无名管道
	if (ret == -1)
	{
		printf("error\n");
		return 0;
	}

	pid_t pid;
	pid = fork();

	#if 1
	if (pid > 0)
	{
	    sleep(5);
		//关闭读端
		close(fd[0]);
		write(fd[1], "hello", 5);
		write(fd[1], "world", 5);
		printf("parent write data\n");
	}
	else if (pid == 0)
	{
		//关闭写端
		close(fd[1]);
		printf("child read data\n");
		char buf[10];
		int n;
		while (1)
		{
			memset(buf, 0, sizeof(buf));
			//默认阻塞读 具体的实现
			n = read(fd[0], buf, sizeof(buf));
			if (n > 0)
			    printf("%d: %s\n", n, buf);
		}
	}
    #endif

	#if 0
	//模拟一种情况：子进程将管道的读端关闭，测试父进程像写端写入数据后会发生什么情况
	//此种情况，父进程在像一个被子进程关闭了读端的管道中写入数据时会产生一个 SIGPIPE，会将父进程终止
	//当进程向一个broken的管道中写入数据时，会产生一个 SIGPIPE
	if (pid > 0)
	{
	    signal(SIGPIPE,func);
	    sleep(5);

	    //关闭读端
		close(fd[0]);

	    write(fd[1], "hello", 5);

	    while (1);
	}
	else if (0 == pid)
	{
	    //关闭读端
		close(fd[0]);
	}
    #endif

	return 0;
}


