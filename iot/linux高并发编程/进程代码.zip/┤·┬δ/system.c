#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	int status;
	status = system("ls -l");
	if(WIFEXITED(status))
		printf("the exit status is %d \n", WEXITSTATUS(status));
	else
		printf("abnornamal exit\n");	

	status = system("./system_test");	
	if(WIFEXITED(status))
		printf("the exit status is %d \n", WEXITSTATUS(status));
	else if (WIFSIGNALED(status))
	{
		printf("exit by signal: %d\n", WTERMSIG(status));
	}

	return 0;
}