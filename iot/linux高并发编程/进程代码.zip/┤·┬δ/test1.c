#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    printf("USER = %s\n", getenv("USER"));
    printf("pwd = %s\n", getenv("pwd"));
    return 0;
}