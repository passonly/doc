#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

void quit_handler(int signum) //信号处理函数
{
	switch (signum)
	{
		case SIGINT:
			printf("get A signal: SIGINT\n");
			break;
		case SIGQUIT:
			printf("get A signal: SIGQUIT\n");
			break;	
	}
	
}

int main(int argc, char *argv[])
{
	//注册两个信号的处理函数
	signal(SIGINT, quit_handler);
	signal(SIGQUIT, quit_handler);

	sigset_t newmask,pendmask;

	sigemptyset(&newmask);

	//将SIGQUIT  SIGINT信号添加到信号集中
    sigaddset(&newmask , SIGQUIT);
    sigaddset(&newmask , SIGINT);

    //将信号集中的信号阻塞
    sigprocmask(SIG_BLOCK , &newmask , NULL);

    sleep(5);

    //获取被阻塞的信号集合
    sigpending(&pendmask);

    //检查SIGINT信号是否被阻塞
     if(sigismember(&pendmask , SIGINT))
     {
        printf("SIGINT pending\n");
     }

     //检查SIGQUIT信号是否被阻塞
     if(sigismember(&pendmask , SIGQUIT))
     {
         printf("SIGQUIT pending\n");
     }
     //将信号集中的信号解除阻塞
     sigprocmask(SIG_UNBLOCK , &newmask , NULL);
     while (1);
    
    return 0;
}
