#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

/*
#include <unistd.h>

extern char **environ;
        
int execl(const char *path, const char *arg, ... );
	   l(list)：参数地址列表，以空指针结尾        
       path：必须指定命令的路径，如果不指定则在当前目录下查找命令  
		
int execlp(const char *file, const char *arg, ...);
	   p(path) 按 PATH 环境变量指定的目录搜索可执行文件。 
       以 p 结尾的 exec 函数取文件名做为参数。当指定 filename 作为参数时，若 filename 中包含/，则将其视为 路径名，并直接到指定的路径中执行程序。             
int execle(const char *path, const char *arg, ...);
		e(environment)： 存有环境变量字符串地址的指针数组的地址。execle 和 execve 改变的是 exec 启动的程序的环境变量（新的 环境变量完全由 	
            environment 指定），其他四个函数启动的程序则使用默认系统环境变量。

int execv(const char *path, char *const argv[]);
int execvp(const char *file, char *const argv[]);
int execvpe(const char *file, char *const argv[], char *const envp[]);

注意：exec函数簇会用新的进程的镜像替换掉原来的进程镜像（将新的进程的代码段替换掉原来进程的代码段，会执行新的进程的代码）
在实际工作中如果需要使用exec函数簇我们一般fork一个子进程，在子进程中调用execl函数簇
*/


int main(int argc, char *argv[])
{
    int ret;

	//execl的第一个参数要填写可执行程序的路径
	pid_t pid = fork();
	if (0 == pid)
   {
	    ret = execl("/bin/ls", "ls", "-a", "-l", "-h", NULL);

	    printf("hello world\n"); //这条语句是不会被执行到的！！因为子进程的代码段会被 ls这个程序的代码段所替换！！！！
   }

#if 0
	//ret = execlp("ls", "ls", "-a", "-l", "-h", NULL);

	//环境变量指针数组
	char *env[]={"USER=ME", "pwd=123456", NULL};

	ret = execle("./test","test", NULL, env);
     //test程序的源代码如下
	/*
		#include <stdio.h>
		#include <unistd.h>
		int main(int argc, char *argv[])
		{
			printf("USER = %s\n", getenv("USER");
			printf("pwd = %s\n", getenv("pwd");
			return 0;
		}
	*/


	//ret = execve("./test", arg, env);
	#endif

	//char *arg[]={"ls", "-a", "-l", "-h", NULL};
	//ret = execv("/bin/ls", arg);

	//ret = execvp("ls", arg);

	char *env[]={"USER=ME", "pwd=123456", NULL};

	char *arg[] ={"test", NULL};
	execvpe("./test", arg, env);
	if (-1 == ret)
		perror("execl");


	return 0;
}