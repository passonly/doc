//设计一个定时器，实现每隔5s打印hello，每到整10分钟打印world
#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <time.h>
#include <list>

using namespace std;

enum en
{
	FIVE, //每隔5s做一件事情
	TEN   //整10分钟做一件事情
};
int seconds[] = {5, 600};

//函数指针
typedef void (*FUNC)();

//定义一个任务结构体
typedef struct task
{
	time_t t; //任务触发的时间点
	FUNC f; //任务对应的处理函数
	int type; //任务类型
}Task;

//任务链表
list<Task> tList;


//每隔5s 执行的函数
void func5()
{
	printf("hello\n");
}

void func10()
{
	printf("world\n");
}

void handler(int signum)
{
    time_t  t = time(NULL);
    //遍历任务链表
    list<Task>::iterator it;

    for (it = tList.begin(); it != tList.end(); it++)
    {
        if (it->t == t)
        {
            it->f();
            it->t += seconds[it->type]; //更新时间结点为下一个5s或者下一个整10
        }
    }
}

void timer_init()
{
	signal(SIGALRM, handler);

	struct itimerval value;
	/*设定初始时间计数为1秒0微秒*/
	value.it_value.tv_sec=1;
	value.it_value.tv_usec=0;
	/*设定执行任务的时间间隔也为1秒0微秒*/
	value.it_interval= value.it_value;
	/*设置计时器ITIMER_REAL*/
	setitimer(ITIMER_REAL,&value, NULL);
}


void task_init(list<Task> &tList)
{
    Task node;

    //添加5s结点
    time_t t = time(NULL);

    node.t = t+seconds[FIVE]; //当前时间+5s
	node.f = func5;
	node.type = FIVE;

	tList.push_back(node);

	//添加10分钟结点
	struct tm *tm;
    tm = localtime(&t); //将秒数转换成时间结构体
    tm->tm_min = tm->tm_min/10 * 10; //获取整10分
    tm->tm_sec = 0;

    t = mktime(tm); //将时间结构体转换成秒数
    node.t = t+seconds[TEN];
	node.f = func10;
	node.type = TEN;

	tList.push_back(node);
}

int main()
{
	task_init(tList);

	timer_init();

	while (1);

	return 0;
}