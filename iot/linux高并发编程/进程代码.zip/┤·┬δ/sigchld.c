#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>

pid_t pid;

void quit_handler(int signum) //信号处理函数
{
	printf("child process exit \n");
	int status;
	wait(&status);
}

int main(int argc, char *argv[])
{
	pid = fork();

	if (pid > 0)
	{
		printf("parent process\n");
		signal(SIGCHLD, quit_handler);
	}
	else if (0 == pid)
	{
	    sleep(1);
		printf("child process\n");
		return 0;
	}

	while (1);
    
    return 0;
}