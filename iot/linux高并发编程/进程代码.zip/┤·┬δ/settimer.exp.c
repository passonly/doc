//设计一个定时器，实现每隔5s打印hello，每到整10分钟打印world
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <time.h>

typedef void (*FUNC)();

enum en
{
	FIVE,
	TEN
};
int seconds[] = {5, 600};

//设计一个链表，节点描述定时的时间和对应的处理函数
typedef struct Node
{
	time_t t;
	FUNC f;
	int type;
	struct Node *next; //指向下一个结点的指针
}Node;

typedef struct List
{
	Node *head;
	Node *tail;
}List;

List *list = NULL;

void func1()
{
	printf("hello\n");
}

void func2()
{
	printf("world\n");
}

void tail_insert(List *list, int type, FUNC f)
{
	if (NULL == list)
		return ;

	time_t t = time(NULL);
	//添加节点
	Node *node = (Node *)malloc(sizeof(Node));
	if (type == TEN)
	{
		//获取当前的分钟数
		struct tm *tm;
		tm = localtime(&t);
		tm->tm_min = tm->tm_min/10 * 10;
		tm->tm_sec = 0;

		t = mktime(tm);
	}
	node->t = t+seconds[type];
	node->f = f;
	node->type = type;
	node->next = NULL;

	//判断链表是否为空
	if (list->head == NULL)
	{
		list->head = node;
		list->tail = node;
		return ;
	}

	list->tail->next = node;
	list->tail = node;
}

List *list_init()
{
	List *list = (List *)malloc(sizeof(List));
	list->head = NULL;
	list->tail = NULL;

	tail_insert(list, FIVE, func1);
	tail_insert(list, TEN, func2);

	return list;
}

void func(int signum)
{
	time_t  t = time(NULL);

	//遍历链表
	Node *tmp;
	tmp = list->head;
	while (tmp)
	{
		if (tmp->t == t)
		{
			tmp->f();
			tmp->t += seconds[tmp->type];
		}
		tmp = tmp->next;
	}
}

void timer_init()
{
	signal(SIGALRM, func);

	struct itimerval value;
	/*设定初始时间计数为1秒0微秒*/
	value.it_value.tv_sec=1;
	value.it_value.tv_usec=0;
	/*设定执行任务的时间间隔也为1秒0微秒*/
	value.it_interval= value.it_value;
	/*设置计时器ITIMER_REAL*/
	setitimer(ITIMER_REAL,&value, NULL);
}

int main()
{
	list = list_init();

	timer_init();

	while (1);
    return 0;
}