#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

#define PATH "/tmp"
#define PROJ_ID 250

struct msgbuf {
    long mtype; //消息的类型
	char mtext[100]; //消息的正文
};


int main()
{
	key_t key;
	key = ftok(PATH, PROJ_ID);
	if (-1 == key)
	{
		perror("ftok error");
		return 0;
	}
	
	int id;
	id = msgget(key, IPC_CREAT | 0644);
	if (-1 == id)
	{
		perror("msgget error");
		return 0;
	}
	
	struct msgbuf  msg;
	msg.mtype = 100;
	memset(msg.mtext, 0, sizeof(msg.mtext));
	strcpy(msg.mtext, "hello world");
	//发送消息
	int ret;
	int i;
	for (i = 0; i < 10; i++)
	{
		ret = msgsnd(id, &msg, sizeof(msg.mtext), 0);
		if (ret == -1)
		{
			perror("msgsnd error");
			return 0;
		}
	}
	
	
	return 0;
}