#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

void quit_handler(int signum) //信号处理函数
{
	switch (signum)
	{
		case SIGINT:
			printf("get A signal: SIGINT\n");
			break;
		case SIGQUIT:
			printf("get A signal: SIGQUIT\n");
			break;	
	}

	int i;
	for (i = 0; i < 5; i++)
    {
	    printf("sleeping ...\n");
	    sleep(1);
    }
}

int main(int argc, char *argv[])
{
    int i = 0;
    struct sigaction act, oldact;
    act.sa_handler = quit_handler;

    sigaddset(&act.sa_mask, SIGQUIT);

   // act.sa_flags = SA_RESETHAND | SA_NODEFER;
    //act.sa_flags = SA_RESETHAND;
    act.sa_flags = 0; //1、能够重复处理同一信号  2、如果在信号处理函数运行期间产生了另外一个信号，不会打断当前的信号处理函数

    sigaction(SIGINT, &act, &oldact);

	while (1);
    
    return 0;
}
