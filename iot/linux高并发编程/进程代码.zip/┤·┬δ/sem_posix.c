#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h>

#define PATH "/tmp"
#define ID 100

#define page_size 4096

int *shm_init()
{
    key_t key;
	//key:代表一个system V IPC
	key = ftok(PATH, ID);
	if (-1 == key)
	{
		perror("ftok error");
		return NULL;
	}

	int id;
	//创建了个system v IPC中的共享内存，而且共享了page_size大小的内存
	id = shmget(key, page_size, IPC_CREAT | 0644);
	if (-1 == id)
	{
		perror("shmget error");
		return NULL;
	}

	//将共享的内存映射到进程的地址空间中
	int *p = (int *)shmat(id, NULL, 0);
	if (p == (void *)-1)
	{
		perror("shmat error");
		return NULL;
	}

	*p = 0;
	return p;
}

void main()
{
	int *p;
	p = shm_init(); //初始化共享内存

	pid_t pid;
	pid = fork();

	if (pid > 0)
	{
	    //创建或者打开一个有名信号量
        sem_t *sem;
        sem = sem_open("/tmp", O_CREAT, 0644, 1);

		int i;
		for (i = 0; i < 10000000; i++)
		{
		    sem_wait(sem);
		    (*p)++;
		    sem_post(sem);
		}

		printf("%d\n", *p);
		sem_close(sem);
		sem_unlink("/tmp");
	}
	else if (pid == 0)
	{
	    //创建或者打开一个有名信号量
        sem_t *sem;
        sem = sem_open("/tmp", O_CREAT, 0644, 1);

		int i;
		for (i = 0; i < 10000000; i++)
		{
		    sem_wait(sem);
		    (*p)++;
		    sem_post(sem);
		}

		printf("%d\n", *p);

		sem_close(sem);
	    sem_unlink("/tmp");
	}

	while (1);
}