#include <stdio.h>

void main()
{
	int x = 10, y = 10;
	int a[x][y] = {0};
}
