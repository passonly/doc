#include <stdio.h>
#include <stdlib.h>

int g_x;
int g_y = 100;
const int g_z;
const int g_m = 100;

void func()
{
	int k;
	static int n = 100;
	static int t;
	printf("int k: %p\n", &k);
	printf("static int n=100: %p\n", &n);
	printf("static int t: %p\n", &t);
}

int main()
{
	int a;
	printf("int a: %p\n", &a);
	printf("int g_x: %p\n", &g_x);
	printf("int g_y=100: %p\n", &g_y);
	printf("const int g_z: %p\n", &g_z);
	printf("const int g_m=100: %p\n", &g_m);

	int *p = (int *)malloc(10);
	printf("int *p: %p\n", p);

	func();
	
	while(1);

	return 0;
}
