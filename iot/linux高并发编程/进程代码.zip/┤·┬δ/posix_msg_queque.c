#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <mqueue.h>
#include <errno.h>
#include <unistd.h>

int main()
{
    mqd_t mq_id;

    mq_id = mq_open("/myqueue", O_RDWR | O_CREAT | O_EXCL, 0666, NULL);
    if (mq_id < 0) //如果创建消息队列失败
    {
        if (errno == EEXIST) //如果出错原因是队列存在
        {
            mq_unlink("/myqueue"); //删除原来的队列
            mq_id = mq_open("/myqueue", O_RDWR | O_CREAT, 0666, NULL);
            if (mq_id < 0)
            {
                printf("open message queue error...\n");
                return 0;
            }
        }
        else
        {
             printf("open message queue error...\n");
             return 0;
        }
    }
    struct mq_attr mqAttr;
    if (mq_getattr(mq_id, &mqAttr) < 0)
    {
        printf("get the message queue attribute error");
        return 0;
    }
    printf("mqAttr.mq_flags：%ld\n", mqAttr.mq_flags);
    printf("mqAttr.mq_maxmsg：%ld\n", mqAttr.mq_maxmsg);
    printf("mqAttr.mq_msgsize：%ld\n", mqAttr.mq_msgsize);
    printf("mqAttr.mq_curmsgs：%ld\n", mqAttr.mq_curmsgs);

    pid_t pid;
    pid = fork();
    if (pid == 0)
    {
        int i = 0;
        char buf[100];

        while (1)
        {
            memset(buf, 0, sizeof(buf));
            sprintf(buf, "The %dst msg ...\n", i+1);
            i++;
            int ret = mq_send(mq_id, buf, sizeof(buf), i);
            printf("ret: %d\n", ret);

            sleep(1);
        }
    }
    else if (pid > 0)
    {
        char buf[mqAttr.mq_msgsize]; //注意：必须大于等于属性值mq_msgsize的值，否则返回EMSGSIZE错误
        int ret;
        while (1)
        {
            //阻塞读取消息
            ret = mq_receive(mq_id, buf, sizeof(buf), NULL);
            printf("%d: %s\n", ret, buf);
        }
    }

    return 0;
}