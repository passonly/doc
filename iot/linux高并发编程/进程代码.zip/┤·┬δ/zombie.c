#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[])
{ 
	
	pid_t pid;
	pid = fork();
	if (pid > 0)
	{
		printf("I am your father\n");

		while (1);
		
	}
	else if (0 == pid)
	{
		printf("I am your child\n");
	} 

	return 0;
}
