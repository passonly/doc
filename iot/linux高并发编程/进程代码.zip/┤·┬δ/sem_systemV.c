#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

#define PATH "/tmp"
#define ID 100

#define PATH1 "/tmp"
#define ID1 101

#define page_size 4096

#define dbgOut(args...) \
do{ \
	char b__[1024]; \
	sprintf(b__,args); \
	fprintf(stdout,"[%s, %s, %d] %s", __FILE__, __FUNCTION__,__LINE__,b__); \
}while(0)


union semun {
               int              val;    /* Value for SETVAL */
               struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
               unsigned short  *array;  /* Array for GETALL, SETALL */
               struct seminfo  *__buf;  /* Buffer for IPC_INFO
                                           (Linux-specific) */
           };

//初始化一个System V的共享内存
int *shm_init()
{
    key_t key;
	//key:代表一个system V IPC
	key = ftok(PATH, ID);
	if (-1 == key)
	{
		perror("ftok error");
		return NULL;
	}

	int id;
	//创建了个system v IPC中的共享内存，而且共享了page_size大小的内存
	id = shmget(key, page_size, IPC_CREAT | 0644);
	if (-1 == id)
	{
		perror("shmget error");
		return NULL;
	}

	//将共享的内存映射到进程的地址空间中
	int *p = (int *)shmat(id, NULL, 0);
	if (p == (void *)-1)
	{
		perror("shmat error");
		return NULL;
	}
    return p;
}

int main()
{
	int *p = shm_init();
    *p = 0;

//使用 system V信号量保障共享资源*p能够数据同步
    key_t key1;
    //key:代表一个system V IPC
    key1 = ftok(PATH1, ID1);
    if (-1 == key1)
    {
        perror("ftok error");
        return 0;
    }

    int id1;
    //通过key1创建一个system V IPC中的信号量
    id1 = semget(key1,1, IPC_CREAT | 0644); //1: 信号量集合中信号量的个数
    if (-1 == id1)
    {
        perror("semget error");
        return 0;
    }
    //设置信号量的初始值
    union semun semun;
    semun.val = 1;
    semctl(id1, 0, SETVAL, semun);

    struct sembuf buf;

	pid_t pid;
	pid = fork();

	if (pid > 0)
	{
		int i;
		for (i = 0; i < 5000000; i++)
		{
			dbgOut("parent p \n");
			//将信号量的值输出
			dbgOut("semval: %d\n", semctl(id1, 0, GETVAL));
			//P操作
			buf.sem_num = 0; //操作信号量集合中的第1个信号量，0：就是操作的信号量在systemV信号量集合中的下标
			buf.sem_op = -1;
			buf.sem_flg = SEM_UNDO;
			semop(id1, &buf, 1); //1：这次P操作操作了信号量集合中的1个信号量

			(*p)++; //临界区代码
			
			dbgOut("sssss\n");
			//V操作
			buf.sem_num = 0;
			buf.sem_op = 1;
			buf.sem_flg = SEM_UNDO;
			semop(id1, &buf, 1);
			
			dbgOut("parent v \n");
			//将信号量的值输出
			dbgOut("semval: %d\n", semctl(id1, 0, GETVAL));
		}
		printf("%d\n", *p);
	}
	else if (pid == 0)
	{
		int i;
		for (i = 0; i < 5000000; i++)
		{
			dbgOut("child p \n");
			dbgOut("semval: %d\n", semctl(id1, 0, GETVAL));
			//P操作
			buf.sem_num = 0;
			buf.sem_op = -1;
			buf.sem_flg = SEM_UNDO;
			semop(id1, &buf, 1);

			(*p)++; //临界区代码

			//V操作
			buf.sem_num = 0;
			buf.sem_op = 1;
			buf.sem_flg = SEM_UNDO;
			semop(id1, &buf, 1);
			dbgOut("child v \n");
			dbgOut("semval: %d\n", semctl(id1, 0, GETVAL));
		}
		printf("%d\n", *p);
	}

	semctl(id1, 0, IPC_RMID, NULL); //将System V信号量从内核中删除
	while (1);
}