#include <stdio.h>
#define RIGHT 1
#define DOWN 2
#define LEFT 3
#define UP 4
#define x 10
#define y 10

int main() {
 int a[x][y] = {0};
 int m = 1, n, direct;
 printf("input n:\n");
 scanf("%d", &n);
 while (m <= n * n) {
  a[x][y] = m++;
  switch (direct) {
   case RIGHT:
    if (a[x][y + 1] != 0) {
     direct = DOWN;
     x++;
    } else
     y++;
    break;
   case LEFT:
    if (a[x][y - 1] != 0) {
     direct = UP;
     x--;
    } else
     y--;
    break;
   case UP:
    if (a[x - 1][y] != 0) {
     direct = DOWN;
     y++;
    } else
     x--;
    break;
   case DOWN:
    if (a[x + 1][y] != 0) {
     direct = RIGHT;
     y--;
    } else
     x++;
    break;
  }
 }
 for (int i = 0; i < n; i++) {
  for (int j = 0; j < n; j++) {
   printf("a[%d][%d]=%d\t", i, j, m);
  }
  printf("\n");
 }
}