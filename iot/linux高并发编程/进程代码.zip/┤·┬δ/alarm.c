#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void func(int signu)
{
    int ret;
    ret = alarm(1);
    printf("ret: %d\n", ret);
    printf("alarm ...\n");
}

void main()
{
	int ret;
	ret = alarm(5);
	printf("ret: %d\n", ret);

	sleep(2);

	ret = alarm(1);
	printf("ret: %d\n", ret);

	signal(SIGALRM, func);
	while (1)
	{
	}
}
