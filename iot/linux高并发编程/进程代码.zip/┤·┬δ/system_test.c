#include <stdio.h>

int main()
{
	printf("system test...\n");
	while (1);
	return 0;
}
