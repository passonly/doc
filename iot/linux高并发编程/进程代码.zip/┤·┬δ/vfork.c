#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[])
{ 
	
	pid_t pid;
	pid = vfork();
	if (pid > 0)
	{
		printf("I am your father\n");
		
	}
	else if (0 == pid)
	{
		printf("I am your child\n");
		sleep(3);

		execl("/bin/ls", "ls", "-l", NULL);
		printf("hello world\n");
	} 

	return 0;
}
