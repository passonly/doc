#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int cnt2; //没有初始化的全局变量在.bss段，而且值为0
static int s_int = 100;  //.data段 数据段
static int s_int2; //没有初始化的全局变量在.bss段，而且值为0

void func()
{
    static int x; //.bss
    static int y = 10; //.data
}

int main(int argc, char *argv[])
{ 
	int a = 100; //栈
	char buf[] = "hello"; //buf: 栈  "hello":栈上
	char *p = "hello"; //p: 栈， "hello": .rodata 只读数据段
	
	pid_t pid;
	pid = fork();
	if (pid > 0)
	{
		printf("I am your father\n");
		//在父进程中修改a的值
		a = 1000;
		printf("parent: %d\n", a); //1000
	}
	else if (0 == pid)
	{
		printf("I am your child\n");
		//在子进程中打印a的值
		printf("child: %d\n", a);  //100 因为子进程和父进程的地址空间
 // 是互相独立的，因为子进程拷贝了父进程的数据，所以在子进程中也有a，但是a的值是
  //父进程修改前的值
	} 

	return 0;
}
