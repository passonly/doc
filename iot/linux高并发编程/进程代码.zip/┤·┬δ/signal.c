#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

void quit_handler(int signum) //信号处理函数
{
	switch (signum)
	{
		case SIGINT:
			printf("get A signal: SIGINT\n");
			signal(SIGINT, quit_handler);
			break;
		case SIGQUIT:
			printf("get A signal: SIGQUIT\n");
			break;	
	}
}

int main(int argc, char *argv[])
{
	//ctrl + c
	signal(SIGINT, quit_handler);
	signal(SIGQUIT, quit_handler);
	//SIGKILL信号的处理方式是不能被改变的
	signal(SIGKILL, quit_handler); 
	while (1);
    
    return 0;
}
