#include <stdio.h>
int main()
{
	printf("hello world\n");
	

	while (1);
	return 0;
}

