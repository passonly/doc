#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	printf("hello");
	exit(0);
//_exit(0);
//	_Exit(0);
	return 0;
}
