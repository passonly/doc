#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <time.h>

void func(int signum)
{
	printf("hello\n");
}	

int main()
{
	pid_t pid;

	pid = fork();

	if (pid > 0)
	{
		sleep(1);
		kill(pid, SIGUSR1);
	}
	else if (0 == pid)
	{
		signal(SIGUSR1, func);
	}

	while (1);
	return 0;
}
