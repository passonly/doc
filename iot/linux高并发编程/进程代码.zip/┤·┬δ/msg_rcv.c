#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

#define PATH "/tmp"
#define PROJ_ID 250

struct msgbuf {
    long mtype;
	char mtext[100];
};

int main()
{
	key_t key;
	key = ftok(PATH, PROJ_ID);
	if (-1 == key)
	{
		perror("ftok error");
		return 0;
	}
	
	int id;
	id = msgget(key, 0);
	if (-1 == id)
	{
		perror("msgget error");
		return 0;
	}
	
	struct msgbuf  msg;
	msg.mtype = 100;
	memset(msg.mtext, 0, sizeof(msg.mtext));
	//接收消息
	while (1)
	{
		int ret;
		ret = msgrcv(id, &msg, sizeof(msg.mtext), msg.mtype, 0);
		if (ret == -1)
		{
			perror("msgsnd error");
			return 0;
		}
		printf("%s\n", msg.mtext);
	}

	return 0;
}