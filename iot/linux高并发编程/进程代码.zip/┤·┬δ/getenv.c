#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	char *value;
	value = getenv("PATH");
	if (value)
		printf("%s\n", value);
	else 
		printf("can not get PATH\n");
	return 0;
}
