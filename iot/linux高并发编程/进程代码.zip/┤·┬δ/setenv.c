#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int ret;

	ret = putenv("env=test");
	if (ret)
	{
		perror("putenv error");
		return 0;
	}

	printf("env: %s\n", getenv("env"));

	ret = setenv("env", "TEST", 0);
	printf("env: %s\n", getenv("env"));

	ret = setenv("env", "TEST", 1);
	printf("env: %s\n", getenv("env"));

	return 0;
}
