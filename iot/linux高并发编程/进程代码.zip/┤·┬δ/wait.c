#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{ 
	
	pid_t pid;
	pid = fork();
	if (pid > 0) //pid的值是创建的新的子进程的PID
	{
		printf("I am your father，My PID：%d, your PID: %d, My parent: %d\n", getpid(), pid, getppid());
		
		int wstatus;
		pid_t pid;
		pid = wait(&wstatus); //阻塞等待子进程的退出，白发人送黑发人
		printf("child process: %d teminated !\n", pid);

		if (WIFEXITED(wstatus))
		{
			printf("%d\n", WEXITSTATUS(wstatus));
		}
		else if (WIFSIGNALED(wstatus))
		{
			printf("%d\n", WTERMSIG(wstatus));
		}
	}
	else if (0 == pid)
	{
		printf("I am your child, Parent PID: %d, My PID: %d\n", getppid(), getpid());

		//exit(5);
		while (1);
	}

	return 0;
}