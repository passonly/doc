#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>

typedef void (*FUNC)();

void func(int signum)
{
	printf("alarm ...\n");
}

void main()
{
	signal(SIGALRM, func);

	struct itimerval value;
	/*设定初始时间计数为5秒0微秒*/
	value.it_value.tv_sec=5;
	value.it_value.tv_usec=0;

	/*设定执行任务的时间间隔也为1秒0微秒*/
	value.it_interval.tv_sec = 1;
	value.it_interval.tv_usec = 0;
	/*设置计时器ITIMER_REAL*/
	setitimer(ITIMER_REAL,&value, NULL);

	while (1);
}
